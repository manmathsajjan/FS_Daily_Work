package com.springBeanCollaboration;

public class Department 
{
	
	private int departmentId;
	private String departmentName;
	
	
	public Department()
	{
		
	}


	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}


	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}


	@Override
	public String toString() 
	{
		return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + "]";
	}
	
	

}
