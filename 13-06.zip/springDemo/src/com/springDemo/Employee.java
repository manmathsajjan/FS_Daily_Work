package com.springDemo;

public class Employee {
	
	private String name;
	private int Id;
	
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Employee(String name, int id) {
		super();
		this.name = name;
		Id = id;
	}



	@Override
	public String toString() {
		return "Employee [name=" + name + ", Id=" + Id + "]";
	}
	
	
	
	

}
