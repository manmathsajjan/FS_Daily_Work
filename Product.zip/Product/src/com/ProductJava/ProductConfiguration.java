package com.ProductJava;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProductConfiguration 
{
	
	@Bean(name="product1")
	public Product Product1()
	{
		return new Product();
	}
	
	@Bean(name="product2")
	public Product Product2()
	{
		return new Product();
	}

}
