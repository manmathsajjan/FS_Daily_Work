package com.ProductJava;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestContainer {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(ProductConfiguration.class);
		
		Product product1 = (Product)context.getBean("product1");
		product1.setId(101);
		product1.setName("Watch");
		product1.setPrice(8754);		
		
		System.out.println(product1.toString());
		
		
		
		Product product2 = (Product)context.getBean("product2");
		product2.setId(102);
		product2.setName("Bike");
		product2.setPrice(258976.45);		
		
		System.out.println(product2.toString());
		
	}

}
