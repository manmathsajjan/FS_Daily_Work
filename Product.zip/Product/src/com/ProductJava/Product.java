package com.ProductJava;

public class Product {
	
	private int Id;
	private String Name;
	private double price;
	
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Product(int id, String name, double price) {
		super();
		Id = id;
		Name = name;
		this.price = price;
	}


	public void setId(int id) {
		Id = id;
	}


	public void setName(String name) {
		Name = name;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Product [Id=" + Id + ", Name=" + Name + ", price=" + price + "]";
	}
	
	
	
	

}
