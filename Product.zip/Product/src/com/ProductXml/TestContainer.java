package com.ProductXml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestContainer {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		
		Product product = (Product)context.getBean("product");
		
		Product product2 = (Product)context.getBean("product2");
		
		
		System.out.println(product.toString());
		
		System.out.println(product2.toString());
		
	}

}
