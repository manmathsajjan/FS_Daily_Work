package customerInfoJava;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestContainer {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(CustomerConfiguration.class);
		
		Customer customer = (Customer)context.getBean("customer1");
		customer.setCustomer_Id(101);
		customer.setCustomer_name("Vedant");
		customer.setCustomer_contact(909697499);
		customer.setBill(5678.89);
		
		System.out.println(customer.toString());
		
		
		
	}

}
