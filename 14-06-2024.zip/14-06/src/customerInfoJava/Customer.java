package customerInfoJava;

public class Customer {
	
	private int Customer_Id;
	private String Customer_name;
	private long Customer_contact;
	private double bill ;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int customer_Id, String customer_name, long customer_contact, double bill) {
		super();
		Customer_Id = customer_Id;
		Customer_name = customer_name;
		Customer_contact = customer_contact;
		this.bill = bill;
	}

	public void setCustomer_Id(int customer_Id) {
		Customer_Id = customer_Id;
	}

	public void setCustomer_name(String customer_name) {
		Customer_name = customer_name;
	}

	public void setCustomer_contact(long customer_contact) {
		Customer_contact = customer_contact;
	}

	public void setBill(double bill) {
		this.bill = bill;
	}

	@Override
	public String toString() {
		return "Customer [Customer_Id=" + Customer_Id + ", Customer_name=" + Customer_name + ", Customer_contact="
				+ Customer_contact + ", bill=" + bill + "]";
	}
	
	

}
