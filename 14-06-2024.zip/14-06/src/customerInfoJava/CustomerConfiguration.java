package customerInfoJava;

import org.springframework.context.annotation.Bean;

import customerInfoJava.Student;

public class CustomerConfiguration {
	
	@Bean(name="customer1")
	public Customer Customer1()
	{
		return new Customer();
	}
	
	

}
