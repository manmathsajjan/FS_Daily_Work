package studentInfoXml;

public class Student {
	
	private int roll;
	private String name;
	private String div;
	private int contact_no;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Student(int roll, String name, String div, int contact_no) {
		super();
		this.roll = roll;
		this.name = name;
		this.div = div;
		this.contact_no = contact_no;
	}

	@Override
	public String toString() {
		return "Student [roll=" + roll + ", name=" + name + ", div=" + div + ", contact_no=" + contact_no + "]";
	}
	

}
